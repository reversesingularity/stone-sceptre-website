# CHAPTER 3: THE COORDINATES (REVISED)

---

## I. THE AFTERMATH

**2023 — Austin Industrial District, 3:47 AM**

The safehouse was a converted warehouse in the industrial district — one of seven Cian maintained across Texas. Reinforced walls. Signal-blocking paint. Enough weapons cached in the basement to supply a small militia.

Sarah hadn't spoken since they arrived.

She sat in the secure room with both children pressed against her, Liam's face buried in her shoulder, Emma's hand gripping her mother's so tightly the knuckles had gone white. The reinforced door was closed. The biometric lock engaged. Sarah's eyes tracked every shadow, every flicker of the fluorescent lights, every creak of the old building settling.

Cian had tried to explain. Had tried to offer context, reassurance, anything that might help her process what she'd witnessed in her living room.

She'd looked at him with eyes that held no anger, no fear — only the cold calculation of a mother determining threat vectors.

"Later," she'd said. "Right now, I need to know my children are safe."

"They are. This room is—"

"*Later*."

He'd left her alone.

Now Cian stood in the main operations room with Brennan, watching his descendant pace like a caged animal. The blood had been cleaned from Brennan's face, the gash on his forehead sealed with butterfly bandages from the safehouse medical kit. But the fury hadn't faded.

"Tell me everything," Brennan said. "Not the mythology. Not the ancient history. Tell me why that thing was in my house tonight, looking at my daughter like she was something it had been *searching* for."

Cian pulled two chairs to the central table. Sat in one. Waited.

Brennan kept pacing.

"Sit down."

"I don't want to sit down. I want to understand why—"

"*Sit down*, Brennan. This conversation is going to take a while, and you're going to need your energy for what comes after."

Something in Cian's voice cut through the adrenaline. Brennan stopped. Looked at the man he'd known as "Uncle Sean" for fifteen years — the quiet materials engineer with the mysterious past, the one who showed up at family gatherings but never stayed long, who sent birthday cards with no return address and Christmas gifts that arrived from different cities each year.

The man who had killed a demon in his living room with a sword that *sang*.

Brennan sat.

---

## II. THE BRIEFING

"The thing in your house was a shedim," Cian began. "A disembodied spirit — what you'd call a demon. They need hosts to interact with the physical world. That delivery driver was innocent. Used. He'll wake up tomorrow with no memory of the past several hours and a headache that'll last a week."

"And the shedim? Where did it go?"

"Fled. When I extracted it from the host, it had a choice — leave or be destroyed. Most choose to leave." Cian's jaw tightened. "It will have reported back to its network before I could banish it. They know I'm protecting you now. They know you're aware."

"Who is 'they'?"

"The Synagogue of Satan." The words landed heavy in the quiet room. "That's what I call them. A network that's been operating since before recorded history — hidden, patient, working toward something I've spent twenty-six centuries trying to understand."

Brennan's eyes narrowed. "Twenty-six centuries."

"I was born in 612 BCE. I was commissioned by the prophet Jeremiah in 586 BCE, the year Babylon destroyed Jerusalem. The sword I carry was forged by Methuselah — yes, *that* Methuselah — from materials older than human civilization. It keeps me alive. It's kept me alive for 2,631 years."

Silence.

Brennan's engineer's mind was working — Cian could see it. Not rejecting the information outright, but cataloging, cross-referencing, looking for inconsistencies.

"The sword," Brennan said slowly. "Emma said it was singing."

"It does that. She shouldn't have been able to hear it — most people can't. But your bloodline..." Cian paused, choosing his words carefully. "Your family descends from my sister Niamh. She was rescued from a Nephilim blood cult the same night I claimed the sword. The blade recognizes her descendants. It always has."

"Nephilim. The giants from Genesis."

"Among other things. The Nephilim were the offspring of fallen angels — the Watchers — who abandoned their stations in heaven to mate with human women. Their children were abominations. Hybrids that should never have existed. The Flood was sent to destroy them." Cian met Brennan's eyes. "It didn't work completely. Their physical bodies drowned, but their spirits survived. Those spirits are what we call demons — the shedim. They've been possessing hosts and working through human agents ever since."

"And they're targeting my family because..."

"Because Niamh's blood was promised to them. She was supposed to be sacrificed to strengthen prison wards holding an ancient weapon. She escaped. They've been hunting her descendants ever since — partly for practical reasons I don't fully understand, partly for revenge." Cian leaned forward. "Tonight wasn't random, Brennan. That shedim came for Emma specifically. It knew her name. It knew your address. Someone sent it."

"Who?"

"That's what I've been trying to find out for three years. I know who leads them — a creature called Naamah, older than the Flood, one of the original Watcher wives. But finding her, understanding what she's building toward..." Cian shook his head. "I've been chasing shadows."

Brennan was quiet for a long moment. Then: "The Cydonia data."

Cian's breath caught.

"You know about that?"

"I know you've been obsessing over something for three years. I know you stopped returning my calls around the same time my rover found something impossible on Mars." Brennan stood, moved to a wall panel, and entered a code. A section of the wall slid back to reveal a concealed terminal — Cian's secure workstation. "You built this safehouse. You installed this equipment. You never told me the password, but I'm a software engineer with a background in aerospace systems. It took me about forty minutes to crack."

Despite everything, Cian almost smiled. "When?"

"Six months ago. I came looking for you. You weren't here, but your files were." Brennan's voice hardened. "Including a folder labeled 'CYDONIA' with my company's proprietary satellite imagery inside."

"I should have told you—"

"Yes. You should have." Brennan activated the terminal. "But since you didn't, I've been running my own analysis. And tonight — after watching a demon try to take my daughter — I think it's time we compared notes."

---

## III. THE ANOMALY

The holographic display filled the space between them — Mars rendered in high-resolution detail, the Cydonia region highlighted in false-color thermal imaging.

"McNeeve Space Systems launched Titan-1 eighteen months ago," Brennan began, his voice shifting into the crisp cadence of a technical briefing. "Next-generation autonomous rover. TitanCam imaging array — 8K resolution, 10:1 optical zoom, full-spectrum capture from near-UV through long-wave infrared. TITAN-GPR ground-penetrating radar rated to thirty meters depth. Onboard AI capable of five hundred meters per sol autonomous navigation." He pulled up a mission timeline. "Primary objective was landing site assessment for future crewed missions. Secondary objective was geological survey of the northern plains."

"And Cydonia?"

"Wasn't on the original mission plan." Brennan zoomed the display to the Cydonia Mensae region. "Titan-1 was surveying Acidalia Planitia, about four hundred kilometers northeast, when the thermal imaging array picked up an anomaly."

He highlighted a data point. The thermal signature pulsed — a warm spot in the cold Martian landscape, consistent and unwavering.

"Surface temperature at Cydonia averages minus sixty Celsius," Brennan continued. "Normal diurnal variation of maybe twenty degrees between day and night. But this signature..." He pulled up a time-lapse. "No variation. Constant output. Day, night, dust storm, clear sky — it doesn't change."

Cian studied the data. "Solar heating?"

"No. Wrong thermal profile. Solar heating creates surface temperature gradients that dissipate at night. This is *subsurface* — something generating heat from below. Constant. Steady. For as long as we've been observing." Brennan's voice dropped. "I rerouted Titan-1 to investigate. Told the board it was a 'geological anomaly requiring closer examination.' Which was technically true."

"What did it find?"

Brennan pulled up the first high-resolution images. The "Face on Mars" filled the display — not the grainy Viking imagery from the 1970s, but crystalline detail that left no room for pareidolia.

The structure was eroded. Millennia of Martian wind and dust had softened its contours. But the underlying geometry was unmistakable: bilateral symmetry too precise for natural formation, carved features that suggested eyes, a mouth, a ceremonial headdress. Not human. Something else. Something *composite*.

"Mastcam-Z on Perseverance can resolve point-seven millimeters at two meters," Brennan said. "TitanCam can do point-three. At this resolution, there's no ambiguity. That's not a mesa that happens to look like a face. That's a *sculpture*."

Cian stared at the image. In his vision — the vision the sword had given him three years ago — he'd seen this place from the inside. The council chamber where the Watchers had gathered. The circular table where Shemyaza had sat at the head. The viewport through which they'd watched Earth spinning in the void.

But he'd never seen the exterior. He'd never known what the building *looked like* from outside.

Now he understood.

"The cherubic form," he breathed. "Lion, ox, eagle, man. The four faces of the throne guardians."

Brennan frowned. "What?"

"In Ezekiel's vision — the prophet Ezekiel — he describes beings around God's throne. Each has four faces: a lion, an ox, an eagle, and a man. The composite image. The *complete* image." Cian pointed at the sculpture. "That's not a human face, Brennan. It's all four faces merged into one. The Watchers built their council chamber in the image of the throne they'd abandoned."

"That's..." Brennan stopped. Processed. "That's either profoundly arrogant or profoundly tragic."

"Both. They were angels who chose to fall. They built a monument to what they'd lost." Cian's voice hardened. "Show me the inscriptions."

---

## IV. THE SCRIPT

Brennan cycled through the imagery until he found the sequence he was looking for. A section of exposed rock at the base of the structure — protected from erosion by an overhang, preserved for millennia in the thin Martian atmosphere.

Carved into the stone were symbols.

Not random marks. Not natural weathering patterns. A *script* — angular, geometric, arranged in deliberate rows with consistent spacing. Each character was composed of precise straight lines intersecting at sharp angles, like runes rendered by a mathematician.

"I ran this through every linguistic database I could access," Brennan said. "Every known alphabet, every archaeological sample, every proposed reconstruction of lost languages. Nothing matches. Not Sumerian. Not Proto-Sinaitic. Not Linear A or B. Not any runic system from any culture." He pulled up a comparison chart. "The geometric regularity suggests a constructed language — something designed rather than evolved. But the character set doesn't correspond to any known phonetic or logographic system."

Mo Chrá hummed against Cian's spine — a low, sustained note that sounded almost like a sigh.

He ignored it. The sword was always making noises.

Cian studied the symbols. In his vision, he'd seen the Watchers writing — their records, their oaths, their meticulous documentation of every decision. But he hadn't seen the *language*. The vision had given him understanding without translation, meaning without medium.

Now, looking at the actual script, he recognized *nothing*.

"I've seen this before," he said slowly. "In the vision. The Watchers kept records — obsessive, detailed records. Armaros was their historian. But I couldn't..." He shook his head. "The vision showed me what they *meant*, not what they *wrote*."

"So you can't read it?"

"No. I recognize the *pattern* — the way they arranged their text, the way they structured their documents. But the characters themselves..." Cian frowned. "Something's wrong."

Brennan pulled up a thermal overlay. "You're not the only one who noticed."

Mo Chrá's hum shifted — a descending tone that, if Cian had been paying attention, sounded remarkably like exasperation.

The inscription appeared again, but now rendered in false-color thermal imaging. The carved grooves showed a different emissivity signature than the surrounding rock — subtle, but measurable. The symbols themselves seemed to... *shimmer* wasn't the right word. Fluctuate. As if the thermal properties of the carved material weren't uniform.

"The rock is basalt," Brennan said. "Standard Martian volcanic material. But the inscriptions are carved into something else — a different mineral layer, or maybe an artificial substrate. The thermal behavior doesn't match any known material in our database." He highlighted a specific region. "Look at the emissivity variance. The carved grooves are reflecting thermal radiation differently than they should. It's like the material has... selective properties."

Cian studied the data, something nagging at the edge of his awareness. The carved grooves. The anomalous thermal response. The material that didn't behave like natural stone.

He'd seen this before.

Not the script — but the *material*. The way it behaved. The subtle wrongness that said *this is not ordinary rock*.

His hand moved to Mo Chrá's hilt.

The sword's hum changed immediately — sharper, more insistent. Almost *eager*.

"What is it?" Brennan asked.

"The material." Cian's voice was distant, his mind working through twenty-six centuries of unexamined observation. "The inscriptions are carved into something I recognize."

"You said you'd never seen the script before."

"I haven't. But the *substrate* — the mineral layer they carved into..." He drew Mo Chrá halfway from the sheath. The blade caught the holographic light and seemed to drink it in, the edge gleaming with that impossible sharpness that never dulled. "This sword was forged from Cydonian ore. Material the Watchers brought with them when they descended. I've carried it for over two thousand years, and I've noticed... properties."

Mo Chrá's hum intensified — a complex chord that Cian had never consciously analyzed. He'd always treated her sounds as background noise. Personality quirks. The eccentricities of a magical weapon.

Now, for the first time, he wondered if he'd been missing something obvious.

"What kind of properties?" Brennan asked.

How to explain? The way Mo Chrá hummed at different frequencies depending on threat proximity. The way she *sang* in combat — not metaphorically, but literally, producing tones that conveyed tactical information. High notes meant threats from the left. Low notes meant movement behind. That particular trill meant *duck, you idiot*.

The way the blade responded to his voice when he pleaded for her cooperation, as if the metal itself was *listening*.

"The sword responds to sound," Cian said slowly, the realization building as he spoke. "Not just vibration — *specific* sounds. Frequencies. She communicates through acoustic patterns I've never fully understood." He looked at the inscriptions floating in holographic suspension. "If the inscriptions are carved into the same material..."

Mo Chrá's hum shifted to something that could only be described as *finally*.

Brennan's eyes widened. "You think they're sound-activated? Some kind of acoustic trigger?"

"I think the Watchers witnessed creation." Cian sheathed the blade slowly, his mind racing. "Scripture says the morning stars *sang together* when God laid the foundations of the earth. The sons of God — including the two hundred who would become Watchers — shouted for joy. They didn't just observe creation. They *heard* it. They heard God speak reality into existence."

"The Word," Brennan murmured. "In the beginning was the Word..."

"Their technology wouldn't be electronic. It wouldn't be based on principles they learned from humans." Cian gestured at the inscriptions. "It would be acoustic. Sound-based. Built on the fundamental frequencies of creation itself."

Brennan was quiet for a long moment, his engineer's mind reframing the problem. Then: "That's actually testable. If the material has acoustic resonance properties, we should be able to detect them. Measure the natural frequencies. Find out what tones it responds to."

"Can your rover do that?"

"Titan-1 has a microphone array for atmospheric analysis. It's not designed for material resonance testing, but..." Brennan pulled up the rover's specifications. "I can improvise. Transmit a frequency sweep through the ground, measure the response in the carved grooves versus the surrounding rock. If there's a difference in acoustic behavior, we'll find it."

"Do it. But don't stop the visual analysis either — we might need both approaches."

Mo Chrá hummed again — a warmer tone this time, though with an undercurrent that Cian could have sworn was smugness.

*You've been trying to tell me*, he thought at the blade. *Haven't you? All these years. Every hum, every song, every frequency. You were demonstrating how Watcher technology works.*

The sword's hum acquired a distinct *what took you so long?* quality.

Twenty-six centuries. Twenty-six centuries he'd carried a key, treated it like a weapon, and never once asked why it *sang*.

"Selective how?" he asked Brennan, returning to the earlier question. "You said the material has selective properties."

"The spectral data is strange. Thermal response varies based on observation angle. It's like the inscriptions behave differently depending on how you look at them — or maybe..." Brennan frowned. "Maybe depending on what *frequency* you observe them at."

"Keep analyzing. Visual, thermal, spectral, acoustic — everything your rover can capture." Cian looked at the angular script one more time. "The Watchers were meticulous. They documented everything. Whatever's written there, it's important enough that they carved it into material designed to last forever."

"And hid the meaning behind... what? A sound-based lock?"

"Perhaps. Or perhaps they simply wrote in the only language they knew — the language of creation. The language of *sound*." Cian touched Mo Chrá's hilt. "We've been trying to *read* these inscriptions. Maybe we're supposed to *hear* them."

Mo Chrá hummed her approval.

Brennan's jaw tightened. "Which brings me to the problem."

---

## V. THE COMPLICATION

"Lockheed Martin owns twenty-three percent of McNeeve Space Systems," Brennan said. "They have two board seats. They get quarterly reports on mission status, resource allocation, and scientific findings."

"They don't know about this?"

"They know Titan-1 diverted to Cydonia. They know I classified it as a 'geological anomaly investigation.' They *don't* know about the thermal signature, the inscriptions, or the ground-penetrating radar data." Brennan pulled up a calendar. "Quarterly review is in six weeks. They're going to want mission updates. They're going to want to see the data."

"And when they see the thermal signature..."

"They'll ask questions I can't answer without admitting I've been sitting on evidence of extraterrestrial construction for over a year." Brennan's voice was flat. "Best case: they take control of the mission, classify everything, and I lose access to my own data. Worst case: this goes to the intelligence community, and suddenly every government on Earth is racing to get to Cydonia."

Cian understood the implications immediately. "The Synagogue has people everywhere. Intelligence agencies, corporate boards, government offices. If this data goes wide—"

"They'll know exactly what we found. And they'll have resources to act on it that we don't."

"Can you stall?"

"I've been stalling for eighteen months. The 'geological investigation' excuse is wearing thin. Mission Control keeps asking why I'm burning fuel and sols on a site that isn't producing publishable science." Brennan rubbed his eyes. "I've got maybe two months before this becomes impossible to hide. Less if Lockheed's board liaison decides to make a surprise visit to review operations."

Cian stood and walked to the display. The inscriptions hung in the air before him — angular, alien, maddeningly unreadable.

"The sword showed me this place three years ago," he said quietly. "I didn't know why. I didn't understand the timing. For 2,631 years, it kept its origin secret — kept the memory of what it witnessed locked away. Then, without warning, without explanation, it showed me everything."

"What changed?"

Cian turned to face Brennan. "You did. Your rover. Human technology, reaching Mars, *seeing* the council chamber for the first time since the Watchers abandoned it."

"You think the sword... responded to that?"

"The blade was forged from Cydonian material — ore that was present when the Watchers swore their oath. Stone has memory, Brennan. The sword remembers what its source witnessed. For five thousand years, no human eyes could see that place. No human mind could act on that knowledge." Cian's voice hardened. "Then your rover photographed the site. And suddenly — for the first time in all of history — knowing the truth became *useful*."

Brennan was quiet for a long moment. "That's... that's a lot to accept."

"I know."

"A sword that thinks. A sword that *plans*."

"She's... complicated." Cian almost smiled. "We've been partners for a long time. I've learned not to question her timing."

"Her?"

"Long story."

Brennan shook his head slowly. Then something shifted in his expression — the engineer reasserting itself, the mind that built spacecraft and solved impossible problems engaging with a new set of parameters.

"Okay," he said. "Okay. Let's assume everything you've told me is true. Fallen angels. Nephilim. A secret war spanning five thousand years. Ancient technology on Mars. My family targeted because of blood that runs back to the Bronze Age." He met Cian's eyes. "What's the play?"

"What do you mean?"

"I mean I've got a rover sitting on the most significant archaeological discovery in human history, a corporation breathing down my neck, a demonic network that just attacked my family, and about two months before everything goes sideways." Brennan's voice sharpened. "I'm not a warrior, Cian. I'm an engineer. Engineers solve problems. So tell me: what's the *mission*?"

Cian studied his descendant — the determination in his eyes, the set of his jaw. Niamh's stubbornness. Niamh's courage. Twenty-six centuries removed, and the blood still ran true.

"The inscriptions," Cian said. "Whatever's written there — that's what we need. The Watchers documented everything. Their records would include the locations of their prisons, the terms of their binding, the timeline of their release. If we can decode that script—"

"We'll know what we're fighting and where to find it."

"Yes."

"Then that's the mission." Brennan turned back to the display. "I can't hide the thermal signature forever, but I can prioritize the inscription data. Get Titan-1 to capture every angle, every wavelength, every possible dataset on those carvings. Full spectral analysis. Maximum resolution." He pulled up a mission planning interface. "The rover's got enough power for another eighteen months of operations. If I focus everything on documentation—"

"You'll have the most complete record possible before anyone else gets access."

"Exactly." Brennan began entering commands. "I'll need to justify the resource allocation. More 'geological investigation' cover stories. But if I phrase it right, I can buy us time."

Cian watched him work — fingers flying across the interface, mind already three steps ahead, treating alien inscriptions and demonic attacks as variables in an engineering problem. This was what mortals did. This was what made them remarkable. They didn't have millennia to process. They had *now*. And they used it.

"Brennan."

"Yeah?"

"Thank you."

Brennan paused. Looked up. "For what?"

"For not running. For not hiding your family and pretending this never happened." Cian's voice roughened. "I've watched your bloodline for twenty-six centuries. Most of them never knew I existed. I kept them safe from the shadows, and they lived normal lives, and they died never understanding why their luck always seemed a little better than it should be." He met Brennan's eyes. "You're the first one who's chosen to fight."

Brennan held his gaze for a long moment. Then: "That thing looked at Emma like she was something it had been *searching* for. Like she was a *prize*." His voice dropped to something quiet and dangerous. "I'm not a warrior. But I'm a father. And no one — *no one* — is going to touch my daughter without going through me first."

**"HE SPEAKETH AS THY SISTER ONCE SPOKE."**

Liaigh's voice, soft in Cian's mind. **"WHEN SHE REFUSED TO FLEE BABYLON WITHOUT THEE."**

Cian didn't respond. But he felt something he hadn't felt in a very long time.

Hope.

---

## VI. THE DECISION

Sarah emerged from the secure room at dawn.

The children were finally asleep — exhaustion overcoming terror, small bodies giving in to the biological imperative of rest. She'd stayed with them until their breathing steadied, until Emma's grip on her brother relaxed, until she was certain they were as safe as they could be.

Then she'd come to find answers.

Cian and Brennan sat at the operations table, surrounded by holographic displays showing Mars terrain, orbital mechanics, and data transmission schedules. They looked up as she approached.

"The children?" Brennan asked.

"Sleeping." Sarah's voice was controlled. Precise. "They'll have nightmares for weeks. Maybe longer. But they're safe." She looked at Cian. "That's because of you."

"The shedim would have—"

"I know what it would have done. I saw its eyes." Sarah didn't flinch. "I'm not here to thank you. I'm here to understand." She pulled a chair to the table and sat. "My husband has spent the last three hours explaining things that should be impossible. Fallen angels. Ancient wars. Blood debts spanning five thousand years." Her eyes met Cian's. "I need to know: is my family going to be safe?"

Cian considered lying. Considered offering reassurance, comfort, the polite fictions that made terrible truths easier to bear.

He rejected the impulse.

"No," he said. "Your family is not going to be safe. Not until this war is over. The attack tonight wasn't random — it was targeted. The Synagogue knows where you live, knows your daughter's name, knows your bloodline's significance. They'll try again."

Sarah absorbed this without visible reaction. "What are our options?"

"I have resources. Safe houses across the country. Contacts in law enforcement and private security who understand the nature of the threat. I can move your family to a secure location, establish layers of protection, make it harder for them to reach you." Cian paused. "But 'harder' isn't 'impossible.' The Synagogue is patient. They've been hunting bloodlines for millennia. Eventually, they'll find you again."

"So hiding buys time, but doesn't solve the problem."

"No."

"What solves the problem?"

Cian glanced at Brennan. At the Mars displays. At the angular inscriptions that still hung in holographic suspension.

"Understanding what they want. Why they're hunting certain bloodlines. What they're building toward." He turned back to Sarah. "The answers are on Mars. Your husband's rover found evidence of the Watchers' presence — their council chamber, their records. If we can decode what's written there, we'll know what we're fighting."

Sarah was quiet for a long moment. Her engineer's mind was working — Cian could see it. The same analytical process Brennan had gone through, compressed into seconds.

"My children come first," she said finally. "Whatever you two are planning — Mars data, ancient inscriptions, cosmic wars — my children come first. If that mission puts them at greater risk, I'll take them somewhere the Synagogue can't find us, and you can fight your war without us."

"I understand."

"Do you?" Sarah's eyes hardened. "Because I've done some reading while my kids were falling asleep. The Book of Enoch. The Book of Jubilees. Your kind of war." She leaned forward. "In those books, everyone dies. The Flood. The destruction of Sodom. The plagues of Egypt. When God fights the enemy, civilians become collateral damage."

"Sarah—" Brennan started.

"I'm not finished." She didn't look away from Cian. "I'm asking you directly, *Uncle Sean*: if it comes down to winning your war or saving my children, which do you choose?"

The silence stretched.

Cian thought of Niamh. Of the night he'd rescued her from the Nephilim altar, when he'd had to choose between claiming the sword and saving his sister. Of the 2,631 years since, when he'd watched her descendants from the shadows, protecting them without their knowledge, losing them to time without ever letting himself get close.

"Your children," he said quietly. "Every time. Without hesitation."

Sarah studied his face for a long moment. Whatever she saw there satisfied her.

"Good." She stood. "Then here's what's going to happen. Brennan is going to keep working on his Mars data. You're going to protect my family while he does. And when you understand what we're facing — when you have an actual *plan* — you're going to tell me everything, and I'm going to decide whether my family stays involved or disappears."

"That's... fair."

"It's not about fair. It's about my children sleeping safely in their beds." Sarah's voice softened slightly. "But for what it's worth — I believe you. I saw what you did tonight. I saw how fast you moved, how you protected Emma without hesitation." She paused at the door to the secure room. "You may not be human anymore, Cian mac Morna. But you're family."

She disappeared into the room where her children slept.

Brennan let out a breath he'd been holding. "That went better than I expected."

"Your wife is remarkable."

"She's terrifying. It's why I married her." Brennan turned back to the displays. "So. We've got a mission, a ticking clock, and a family to protect. What's our next move?"

Cian looked at the inscriptions one last time. Angular. Geometric. Unreadable.

For now.

"We document everything your rover can capture. Full spectral analysis, every wavelength TitanCam can image. There's something strange about those inscriptions — the thermal data doesn't match known materials. Maybe the answer is hiding in a frequency we haven't checked yet."

"And if it's not?"

"Then we find another way. The Watchers left records — I'm certain of it. Those records survived five thousand years on Mars. They'll survive long enough for us to decode them."

**"THE FATHER DOTH NOT REVEAL TRUTH BEFORE ITS TIME,"** Liaigh murmured in his mind. **"BUT WHEN THE TIME IS COME, ALL SHALL BE MADE CLEAR."**

Cian hoped he was right.

Outside the safehouse, the Texas dawn broke over Austin's industrial district — another day beginning, another chapter in a war that had started before human civilization existed.

Inside, a father planned missions to Mars, a mother guarded her sleeping children, and an ancient warrior wondered what secrets were hidden in inscriptions that refused to be read.

The answers were coming.

They just had to survive long enough to find them.

---

## CHAPTER 3 — CRAFT NOTES

### Purpose in Narrative Arc

| Element | Implementation | Reader Effect |
|---------|----------------|---------------|
| **Sarah's Role** | Maternal protection, not analytical takeover | Grounded, believable priorities |
| **Cian + Brennan Briefing** | Men alone, technical deep-dive | Establishes working partnership |
| **Titan-1 Specifications** | Real-world-grounded technology | Credibility for insufferable proofreader |
| **The Inscriptions Mystery** | Angular script, anomalous thermal data | Plants seeds for later payoff |
| **The Lockheed Problem** | Corporate/political tension | Ticking clock, external pressure |
| **Sarah's Ultimatum** | Children first, or she disappears | Stakes clarified, character agency |

### Technical Grounding

| Technology | Real-World Basis | Titan-1 Enhancement |
|------------|-----------------|---------------------|
| **Mastcam-Z** | 1648×1214 px, 4:1 zoom, 0.7mm at 2m | TitanCam: 8K, 10:1 zoom, 0.3mm at 2m |
| **RIMFAX** | 150-1200 MHz GPR, 10-20m depth | TITAN-GPR: 30m depth, enhanced resolution |
| **Thermal Imaging** | Limited LWIR on Perseverance | Full thermal array, ±0.1°C sensitivity |
| **Autonomous Nav** | ~100m/sol with Earth oversight | 500m/sol with onboard AI |

### The Inscription Mystery (Setup)

| Chapter 3 Plants | Later Payoff |
|-----------------|--------------|
| Script doesn't match any known language | It's not *meant* to be read in visible light |
| Anomalous thermal emissivity in carved grooves | Dichroic metamaterial reveals second script layer |
| "Something's wrong" — Cian's instinct | The "wrong" feeling is because he *should* recognize it |
| "Selective properties" — Brennan's observation | Wavelength-selective optical response |

### Character Dynamics

| Relationship | Dynamic | Sample |
|--------------|---------|--------|
| **Cian ↔ Brennan** | Warrior + Engineer, mutual respect | "Engineers solve problems. What's the mission?" |
| **Sarah ↔ Cian** | Protective mother + Ancient warrior | "Your children. Every time. Without hesitation." |
| **Cian ↔ Liaigh** | Warrior + Guardian angel | Quiet observations, divine patience |

### Continuity From Chapters 1-2

| Previous Element | Chapter 3 Pickup |
|-----------------|------------------|
| Cian's vision (Ch 1) | Recognizes council chamber exterior |
| Mo Chrá's timing | Explained as response to human observation |
| Attack on Emma (Ch 2) | Drives Brennan's determination |
| Niamh's letter (Ch 2) | Sarah references "your kind of war" |

### Foreshadowing Seeds

| Seed | Future Payoff |
|------|---------------|
| Anomalous emissivity in inscriptions | NIR spectral analysis reveals paleo-Hebrew |
| "Selective properties" of carved material | Dichroic metamaterial properties |
| Lockheed quarterly review | External pressure in later chapters |
| Sarah's ultimatum | Potential tension if mission endangers children |
| "All shall be made clear" (Liaigh) | Divine timing of revelation |

---

*Word Count: ~4,100 words*
*Drafted: January 20, 2026*
*Major revision: Removed Sarah's analytical takeover, DNA matching subplot, crewed Mars mission. Added technical grounding, inscription mystery setup, Lockheed complication.*
