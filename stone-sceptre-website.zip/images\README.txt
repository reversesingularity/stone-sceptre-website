INSTRUCTIONS FOR BOOK COVER IMAGE:

Please save the stained glass book cover image as "book-cover.jpg" in this directory.

The image should be named exactly: book-cover.jpg

This will replace the current CSS-generated book cover with the beautiful stained glass artwork.
